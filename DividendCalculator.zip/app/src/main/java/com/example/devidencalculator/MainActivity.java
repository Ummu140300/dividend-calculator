package com.example.devidencalculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    EditText editFund, editRate, editMonths;
    TextView textResult;
    Button btnCalculate, btnAbout;
    DecimalFormat formatter = new DecimalFormat("0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editFund = findViewById(R.id.editFund);
        editRate = findViewById(R.id.editRate);
        editMonths = findViewById(R.id.editMonths);
        textResult = findViewById(R.id.textResult);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnAbout = findViewById(R.id.btnAbout);

        btnCalculate.setOnClickListener(view -> {
            try {
                double fund = Double.parseDouble(editFund.getText().toString());
                double rate = Double.parseDouble(editRate.getText().toString());
                int months = Integer.parseInt(editMonths.getText().toString());

                if (months < 1 || months > 12) {
                    Toast.makeText(this, "Enter months between 1 and 12.", Toast.LENGTH_SHORT).show();
                    return;
                }

                double monthlyDividend = (rate / 100 / 12) * fund;
                double totalDividend = monthlyDividend * months;

                String result = "Monthly Dividend: RM " + formatter.format(monthlyDividend) +
                        "\nTotal Dividend: RM " + formatter.format(totalDividend);
                textResult.setText(result);

            } catch (Exception e) {
                Toast.makeText(this, "Please fill all fields with valid numbers.", Toast.LENGTH_SHORT).show();
            }
        });

        btnAbout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        });
    }
}